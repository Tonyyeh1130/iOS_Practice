//: Playground - noun: a place where people can play

import UIKit

//作業5-2: 算全部格子內數字的總合 : 8x8 二元陣列

//瀏覽陣列中每個元素,每個元素的值域等於行列的index相乘
var sum1 = 0

for column in 0...7 {
    for row in 0...7 {
        var value = column * row
        //累加每個元素的值
        sum1  += value
    }
}
var message1 = "全部格子內數字的總合為\(sum1)"

sum1 = 0
//計算效能的優化可以改成這樣
for column in 1...7 {
    for row in 1...7 {
        var value = column * row
        sum1  += value
    }
}
message1 = "全部格子內數字的總合為\(sum1)"

//作業5-3: 奇數行的數字總合
var sum2 = 0

for column in 1...7 where column%2 == 1 {
    for row in 1...7 {
        var value = column * row
        //print(value)
        sum2 += value
    }
}
var message2 = "奇數行的數字總合為\(sum2)"

//作業5-4: 所有格子的總合，除了列數>=行數的格子
var sum3 = 0

for column in 1...7 {
    for row in 1...7 {
        //排除列數>=行數的格子
        if row < column {
            var value = column * row
            //print(value)
            sum3  += value
        }
    }
}
var message3 = "所有格子的總合，除了列數>=行數的格子為\(sum3)"
