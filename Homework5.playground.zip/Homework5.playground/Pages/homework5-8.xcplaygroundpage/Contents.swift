//: [Previous](@previous)

import Foundation

//所有格子的總合，除了列數>=行數的格子, 定義function，接受2個參數，分別代表行數和列數

func count(Column: Int , Row: Int) -> String {
    var sum = 0
    let indexColumn = Column - 1
    let indexRow = Row - 1
    
    for indexColumn in 1...indexColumn {
        for indexRow in 1...indexRow where indexRow < indexColumn {
            let value = indexColumn * indexRow
            sum += value
        }
    }
    
    return "所有格子的總合，(除了列數>=行數的格子)為\(sum)"
}

var result = count(Column: 8, Row: 8)