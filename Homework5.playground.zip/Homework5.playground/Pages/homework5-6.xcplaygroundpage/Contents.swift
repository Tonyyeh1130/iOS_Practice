//: [Previous](@previous)

import Foundation

//定義function，接受3個參數，起始值，最大值和決定數字倍數的number， 回傳運算結果
//比方起始值3，最大值11，決定數字倍數的number為5時，(不包含5的倍數)  運算結果為 3 + 4 + 6 + 7 + 8 + 9 + 11

func count(MinNumber: Int, MaxNumber: Int, Multiple: Int) -> Int {
    var sum = 0
    
    for i in MinNumber...MaxNumber where i % Multiple != 0 {
        sum += i
    }
    
    return sum
}

var result = count(MinNumber: 3, MaxNumber: 11, Multiple: 5)

