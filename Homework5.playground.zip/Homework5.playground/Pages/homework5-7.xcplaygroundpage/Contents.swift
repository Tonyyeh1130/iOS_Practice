//: [Previous](@previous)

import Foundation

//奇數行的數字總合, 定義function，接受2個參數，分別代表行數和列數

func count(Column: Int , Row: Int) -> String {
    var sum = 0
    let indexColumn = Column - 1
    let indexRow = Row - 1
    
    for indexColumn in 1...indexColumn where indexColumn%2 == 1 {
        for indexRow in 1...indexRow {
            let value = indexColumn * indexRow
            sum += value
        }
    }
    
    return "奇數行的數字總合為\(sum)"
}

var result = count(Column: 8, Row: 8)


