//: [Previous](@previous)

import Foundation

//定義一個function，接受一個參數代表華式溫度 ， 回傳攝式溫度

func FahrenheitToCelsius(Fahrenheit: Double) -> Double {
    
    let Celsius = (Fahrenheit - 32) * 5/9
    
    return Celsius
}

var result = "攝氏溫度為\(FahrenheitToCelsius(Fahrenheit: 212))度"

var result2 = "攝氏溫度為\(FahrenheitToCelsius(Fahrenheit: 32))度"